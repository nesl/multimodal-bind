import torch
import torch.nn as nn
import torch.nn.functional as F

class acc_encoder(nn.Module):
    """
    CNN layers applied on acc sensor data to generate pre-softmax
    ---
    params for __init__():
        input_size: e.g. 1
        num_classes: e.g. 6
    forward():
        Input: data
        Output: pre-softmax
    """
    def __init__(self, input_size):
        super().__init__()

        # Extract features, 2D conv layers
        self.features = nn.Sequential(
            nn.Conv2d(input_size, 64, 2),
            nn.BatchNorm2d(64),
            nn.ReLU(inplace=True),
            nn.Dropout(),

            # nn.Conv2d(64, 64, 2),
            # nn.BatchNorm2d(64),
            # nn.ReLU(inplace=True),
            # nn.Dropout(),

            nn.Conv2d(64, 32, 1),
            nn.BatchNorm2d(32),
            nn.ReLU(inplace=True),
            nn.Dropout(),

            nn.Conv2d(32, 16, 1),
            nn.BatchNorm2d(16),
            nn.ReLU(inplace=True),

            )

        self.gru = nn.GRU(238, 120, 2, batch_first=True)

    def forward(self, x):

        self.gru.flatten_parameters()
        x = self.features(x)

        x = x.view(x.size(0), 16, -1)
        # print(x.shape)

        x, _ = self.gru(x)

        x = x.reshape(x.size(0), -1)

        return x


class gyro_encoder(nn.Module):
    """
    CNN layers applied on gyro sensor data to generate pre-softmax
    ---
    params for __init__():
        input_size: e.g. 1
        num_classes: e.g. 6
    forward():
        Input: data
        Output: pre-softmax
    """
    def __init__(self, input_size):
        super().__init__()

        # Extract features, 2D conv layers
        self.features = nn.Sequential(
            nn.Conv2d(input_size, 64, 2),
            nn.BatchNorm2d(64),
            nn.ReLU(inplace=True),
            nn.Dropout(),

            # nn.Conv2d(64, 64, 2),
            # nn.BatchNorm2d(64),
            # nn.ReLU(inplace=True),
            # nn.Dropout(),

            nn.Conv2d(64, 32, 1),
            nn.BatchNorm2d(32),
            nn.ReLU(inplace=True),
            nn.Dropout(),

            nn.Conv2d(32, 16, 1),
            nn.BatchNorm2d(16),
            nn.ReLU(inplace=True),

            )

        self.gru = nn.GRU(238, 120, 2, batch_first=True)

    def forward(self, x):

        self.gru.flatten_parameters()
        x = self.features(x)

        x = x.view(x.size(0), 16, -1)
        # print(x.shape)

        x, _ = self.gru(x)

        x = x.reshape(x.size(0), -1)

        return x

class acc_decoder(nn.Module):
    """
    CNN layers applied on acc sensor data to generate pre-softmax
    ---
    params for __init__():
        input_size: e.g. 1
        num_classes: e.g. 6
    forward():
        Input: data
        Output: pre-softmax
    """
    def __init__(self, input_size):
        super().__init__()

        # Extract features, 2D conv layers
        self.features = nn.Sequential(
            nn.ConvTranspose2d(16, 32, 1),  # Inverse of previous Conv2d
            nn.BatchNorm2d(32),
            nn.ReLU(inplace=True),

            nn.ConvTranspose2d(32, 64, 1),  # Inverse of previous Conv2d
            nn.BatchNorm2d(64),
            nn.ReLU(inplace=True),

            nn.ConvTranspose2d(64, input_size, 2),  # Inverse of previous Conv2d
            nn.BatchNorm2d(input_size),
            nn.ReLU(inplace=True),
        )

        self.gru = nn.GRU(120, 238, 2, batch_first=True)

    def forward(self, x):

        self.gru.flatten_parameters()

        x = x.view(x.size(0), 16, 120)

        x, _ = self.gru(x)

        x = x.view(x.size(0), 16, 119, 2)

        x = self.features(x)

        # print(x.shape)

        return x
    
class gyro_decoder(nn.Module):
    """
    CNN layers applied on acc sensor data to generate pre-softmax
    ---
    params for __init__():
        input_size: e.g. 1
        num_classes: e.g. 6
    forward():
        Input: data
        Output: pre-softmax
    """
    def __init__(self, input_size):
        super().__init__()

        # Extract features, 2D conv layers
        self.features = nn.Sequential(
            nn.ConvTranspose2d(16, 32, 1),  # Inverse of previous Conv2d
            nn.BatchNorm2d(32),
            nn.ReLU(inplace=True),

            nn.ConvTranspose2d(32, 64, 1),  # Inverse of previous Conv2d
            nn.BatchNorm2d(64),
            nn.ReLU(inplace=True),

            nn.ConvTranspose2d(64, input_size, 2),  # Inverse of previous Conv2d
            nn.BatchNorm2d(input_size),
            nn.ReLU(inplace=True),
        )

        self.gru = nn.GRU(120, 238, 2, batch_first=True)

    def forward(self, x):

        self.gru.flatten_parameters()

        x = x.view(x.size(0), 16, 120)

        x, _ = self.gru(x)

        x = x.view(x.size(0), 16, 119, 2)

        x = self.features(x)

        # print(x.shape)

        return x
    
class MyUTDmodel_multimodal_AE(nn.Module):
    """Model for human-activity-recognition."""
    def __init__(self, input_size):
        super().__init__()

        self.acc_encoder = acc_encoder(input_size)
        self.acc_decoder = acc_decoder(input_size)

        self.gyro_encoder = gyro_encoder(input_size)
        self.gyro_decoder = gyro_decoder(input_size)

        # Classify output, fully connected layers
        self.head = nn.Sequential(

            nn.Linear(3840, 1920),
            nn.BatchNorm1d(1920),
            nn.ReLU(inplace=True),

            # nn.Linear(1920, 1920),
            )
        
    def forward(self, x1, x2):

        acc_feature = self.acc_encoder(x1)
        gyro_feature = self.gyro_encoder(x2)

        #print(acc_feature.shape, gyro_feature.shape)
        output = torch.cat((acc_feature,gyro_feature), dim=1) #concate
        output = self.head(output)

        acc_output = self.acc_decoder(output)
        gyro_output = self.gyro_decoder(output)

        return acc_output, gyro_output
    


class MyUTDmodel_IMU(nn.Module):
    """Model for human-activity-recognition."""
    def __init__(self, input_size, num_classes):
        super().__init__()

        self.acc_encoder = acc_encoder(input_size)
        self.gyro_encoder = gyro_encoder(input_size)


        # Classify output, fully connected layers
        self.classifier = nn.Sequential(

            nn.Linear(3840, 1280),
            nn.BatchNorm1d(1280),
            nn.ReLU(inplace=True),

            nn.Linear(1280, 128),
            nn.BatchNorm1d(128),
            nn.ReLU(inplace=True),

            nn.Linear(128, num_classes),
            )


    def forward(self, x1, x2):

        acc_output = self.acc_encoder(x1)
        gyro_output = self.gyro_encoder(x2)

        fused_feature = torch.cat((acc_output,gyro_output), dim=1) #concate
        

        output = self.classifier(fused_feature)

        return output

