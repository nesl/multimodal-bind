import torch
import torch.nn as nn
import torch.nn.functional as F

from models.single_modality import acc_decoder, gyro_decoder, skeleton_encoder
    

class MyUTDmodel_skeleton_to_acc(nn.Module):
    """Model for human-activity-recognition."""
    def __init__(self, input_size):
        super().__init__()

        self.skeleton_encoder = skeleton_encoder(input_size)
        self.acc_decoder = acc_decoder(input_size)

        
    def forward(self, x1):

        feature = self.skeleton_encoder(x1)

        acc_output = self.acc_decoder(feature)


        return acc_output
    

class MyUTDmodel_skeleton_to_gyro(nn.Module):
    """Model for human-activity-recognition."""
    def __init__(self, input_size):
        super().__init__()

        self.skeleton_encoder = skeleton_encoder(input_size)
        self.gyro_decoder = gyro_decoder(input_size)

    def forward(self, x1):

        feature = self.skeleton_encoder(x1)

        gyro_output = self.gyro_decoder(feature)


        return gyro_output

